--expected 6 length
SELECT DISTINCT * FROM Sailors;

--expected 3 length
SELECT DISTINCT B FROM Sailors S;

--expected 4 length
SELECT DISTINCT H FROM Reserves LOLWTFBBQ;