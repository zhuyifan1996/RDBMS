package cs4321test;

import java.io.IOException;

import net.sf.jsqlparser.parser.ParseException;

import org.junit.Test;

import main.Logger;

/**
 * Tests the planner which takes in parsed SQL and plans out the operation order
 * @author Trevor Edwards
 *
 */
public class PlannerTest {

	/**
	 * TODO: More tests for planner
	 * Tests if the first statement becomes a select statement in the planner.
	 * @throws IOException 
	 * @throws ParseException 
	 */
	@Test
	public void testTreeConstruction() throws IOException, ParseException {
		//TODO
		Logger.println("Running planner test (TODO)");
	}
		
}
