package main;

import java.io.File;
import java.io.FileReader;

import db.BufferTupleReader;
import db.BufferTupleWriter;
import db.Schema;
import db.SimpleTupleReader;
import db.SimpleTupleWriter;
import db.SystemCatalogue;
import db.TupleReader;
import db.TupleWriter;
import planner.SqlStatementVisitor;
import net.sf.jsqlparser.parser.CCJSqlParser;
import net.sf.jsqlparser.statement.Statement;

/**
 * This is the main class that set up the system
 * It interpret the command line arguments, reads input and compute the output.
 * @author Guandao Yang
 */
public class Main {
	// Configuration for tests 
	public static boolean setSortConfig = false; // determine whether override the config file
	public static int sortNum;
	public static int sortBuffers;	
	public static boolean setJoinConfig = false;	
	public static int joinNum;
	public static int joinBuffers;
	
	// flag on whether we should have the tuple fully sorted on all fields
	public static boolean fullySorted = false;

	
	// whether we want to use binary format
	public static boolean INPUT_BINARY_FORMAT	= true;
	public static boolean OUTPUT_BINARY_FORMAT 	= true;
	
	// Directory configurations
	public static final String DEFAULT_INPUT_DIRECTORY  = "input";
	public static final String DEFAULT_OUTPUT_DIRECTORY = "output";
	public static final String DEFAULT_TEMP_DIRECTORY 	= "tmp";
	private static String TMP = "tmp";
	
	/**
	 * Reset options to clean up the statics variables every time before it runs
	 */
	public static void reset(){
		Main.setJoinConfig = false;
		Main.setSortConfig = false;
		Main.INPUT_BINARY_FORMAT = true;
		Main.OUTPUT_BINARY_FORMAT = true;
		SystemCatalogue.setSetInputFormat("");
		
		// erase current tmp
		cleanUpTmpDirRecursively(TMP);
	}
	
	public static void main(String[] args) {
//		Main.reset();
		String inputPath = (args.length > 0 ) ? args[0] : DEFAULT_INPUT_DIRECTORY;
		String outFile 	 = (args.length > 1 ) ? args[1] : DEFAULT_OUTPUT_DIRECTORY;
		String tmpPath   = (args.length > 2 ) ? args[2] : DEFAULT_TEMP_DIRECTORY;
		TMP = tmpPath;
		
		try {			
			// make sure the temporary directory exitst
			File tmpDirFolder = new File(tmpPath); 
			// TODO how to clean up the tmp directory			
			tmpDirFolder.delete();
			if (!tmpDirFolder.exists() && !tmpDirFolder.mkdirs()){
				Logger.warnln("Temporary directory "+tmpPath +" doesn't exists.");			
			}
			
			SystemCatalogue.setupSharedInstance(inputPath, tmpPath);
			CCJSqlParser parser = new CCJSqlParser(new FileReader(inputPath+"/queries.sql"));

			Statement statement;
			int counter = 1;
			while ((statement = parser.Statement()) != null) {
				evaluateStatement( statement, outFile, tmpPath, counter );
				counter++;
				
				// clean up the temporary direcotyr
				cleanUpTmpDirRecursively(tmpPath);
			}
		} catch (Exception e) {
			System.err.println("Exception occurred while loading.");
			// clean up the temporary direcotyr
			cleanUpTmpDirRecursively(tmpPath);
			e.printStackTrace();
		}
	}
	
	/**
	 * Recursively clean up all the directly under level dir
	 * @param dir
	 */
	public static void cleanUpTmpDirRecursively(String dir){		
		File tmp = new File(dir);
		for (String file:tmp.list()){
			File newFile = new File(tmp.getAbsolutePath()+"/"+file);
			if (newFile.exists() && newFile.isDirectory()){
				cleanUpTmpDirRecursively(tmp.getAbsolutePath()+"/"+file);
			}
			newFile.delete();
		}		
	}

	/**
	 * Factors out evaluation process
	 * @param statement The statement to process
	 * @param out The filename for output
	 */
	public static void evaluateStatement(Statement statement, String outFile, String tmpDir, int counter){
		
		try{
			// construct the output
			File f = new File(outFile+"/query"+counter);
			Logger.println("Evaluating query" + counter );
			SqlStatementVisitor sVisitor = new SqlStatementVisitor(f);
			statement.accept(sVisitor);
			
			// clean up the temporary directory after each query evaluation
			(new File(tmpDir)).delete();
			(new File(tmpDir)).mkdir();
			Logger.println("Finished evaluating query " + counter);
		} catch(Exception e){
			Logger.println("Encountered a terminating exception in processing query " + counter );
			e.printStackTrace();
		} catch(Error e){
			Logger.println("Encountered a terminating error in processing query " + counter );
			e.printStackTrace();
		}

	}
	
	/**
	 * Update the Join Configuration (for test purpose)
	 * @param ops
	 */
	public static void setJoinOptions(int[] ops){
		Main.joinNum = ops[0];
		if( Main.joinNum == 1 ){
			Main.joinBuffers = ops[1];
		}
		Main.setJoinConfig = true;
	}
	
	/**
	 * Update the Sort Configuration (for testing purpose)
	 * @param ops
	 */
	public static void setSortOptions(int[] ops){
		Main.sortNum = ops[0];
		if( Main.sortNum == 1){
			Main.sortBuffers = ops[1];
		}
		Main.setSortConfig = true;
	}
	
	/**
	 * Reader factory;
	 * @param file
	 * @param scma
	 * @return the reader according to system configuration
	 */
	public static TupleReader tupleReaderFactory(File file, Schema scma){
		if (Main.INPUT_BINARY_FORMAT){
			return new BufferTupleReader(file, scma, SystemCatalogue.PAGE_SIZE);	
		}else{
			return new SimpleTupleReader(file, scma);
		}		
	}
	
	/**
	 * Writer Factory
	 * @param file
	 * @param scma
	 * @return the default writer according to system configuration
	 */
	public static TupleWriter tupleWriterFacotry(File file, Schema scma){
		if (Main.OUTPUT_BINARY_FORMAT){
			return new BufferTupleWriter(file, scma, SystemCatalogue.PAGE_SIZE);	
		}else{
			TupleWriter writer = new SimpleTupleWriter(file);
			writer.setOutputSchema(scma);
			return writer;
		}	
	}
}
